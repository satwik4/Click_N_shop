import 'dart:ui';

import 'package:flutter/material.dart';

// const defaultColor = Colors.deepOrange;
const defaultColor = Colors.blue;