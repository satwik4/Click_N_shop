// import 'package:click_n_shop/models/search_model.dart';
// import 'package:click_n_shop/modules/search/cubit/_state.dart';
// import 'package:click_n_shop/shared/components/constants.dart';
// import 'package:click_n_shop/shared/network/end_points.dart';
// import 'package:click_n_shop/shared/network/remote/dio_helper.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
//
// class SearchCubit extends Cubit<SearchStates> {
//   SearchCubit() : super(SearchInitialState());
//
//   static SearchCubit get(context) => BlocProvider.of(context);
//
//
//
// }
