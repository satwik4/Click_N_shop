package com.example.click_n_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
